def multiplica(a, b):
    result = a * b - a
    return result

print(multiplica(5, 6))
