from antlr4 import *
from traducePyaJavaLexer import traducePyaJavaLexer
from traducePyaJavaParser import traducePyaJavaParser
from traductor import traductor

def main():
    in_code = input('File name:')
    try:
        with open(in_code, 'r') as fileope:
            lexer = traducePyaJavaLexer(InputStream(fileope.read()))
            stream = CommonTokenStream(lexer)
            parser = traducePyaJavaParser(stream)
            tree = parser.prog()

            traductor_obj = traductor()
            walker = ParseTreeWalker()
            walker.walk(traductor_obj, tree)

            #Archivo JAVA
            nombre_archivo_salida = in_code.replace('.py', '.java')
            with open(nombre_archivo_salida, 'w') as archivo_salida:
                archivo_salida.write(traductor_obj.get_codigo_java())

            print(f"Código Java guardado en: {nombre_archivo_salida}")

    except FileNotFoundError:
        print(f"El archivo '{in_code}' no existe.")
    except Exception as e:
        print(f"Error procesando el archivo: {e}")

if __name__ == "__main__":
    main()
