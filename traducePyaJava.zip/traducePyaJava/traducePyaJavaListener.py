# Generated from C:/Users/Irene/Desktop/AutomataAntelr/traducePyaJava/traducePyaJava.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .traducePyaJavaParser import traducePyaJavaParser
else:
    from traducePyaJavaParser import traducePyaJavaParser

# This class defines a complete listener for a parse tree produced by traducePyaJavaParser.
class traducePyaJavaListener(ParseTreeListener):

    # Enter a parse tree produced by traducePyaJavaParser#prog.
    def enterProg(self, ctx:traducePyaJavaParser.ProgContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#prog.
    def exitProg(self, ctx:traducePyaJavaParser.ProgContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#stmt.
    def enterStmt(self, ctx:traducePyaJavaParser.StmtContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#stmt.
    def exitStmt(self, ctx:traducePyaJavaParser.StmtContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#func_def.
    def enterFunc_def(self, ctx:traducePyaJavaParser.Func_defContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#func_def.
    def exitFunc_def(self, ctx:traducePyaJavaParser.Func_defContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#param_list.
    def enterParam_list(self, ctx:traducePyaJavaParser.Param_listContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#param_list.
    def exitParam_list(self, ctx:traducePyaJavaParser.Param_listContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#stmt_block.
    def enterStmt_block(self, ctx:traducePyaJavaParser.Stmt_blockContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#stmt_block.
    def exitStmt_block(self, ctx:traducePyaJavaParser.Stmt_blockContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#expr_stmt.
    def enterExpr_stmt(self, ctx:traducePyaJavaParser.Expr_stmtContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#expr_stmt.
    def exitExpr_stmt(self, ctx:traducePyaJavaParser.Expr_stmtContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#return_stmt.
    def enterReturn_stmt(self, ctx:traducePyaJavaParser.Return_stmtContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#return_stmt.
    def exitReturn_stmt(self, ctx:traducePyaJavaParser.Return_stmtContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#print_stmt.
    def enterPrint_stmt(self, ctx:traducePyaJavaParser.Print_stmtContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#print_stmt.
    def exitPrint_stmt(self, ctx:traducePyaJavaParser.Print_stmtContext):
        pass


    # Enter a parse tree produced by traducePyaJavaParser#expr.
    def enterExpr(self, ctx:traducePyaJavaParser.ExprContext):
        pass

    # Exit a parse tree produced by traducePyaJavaParser#expr.
    def exitExpr(self, ctx:traducePyaJavaParser.ExprContext):
        pass



del traducePyaJavaParser