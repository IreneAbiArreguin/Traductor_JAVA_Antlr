# Generated from C:/Users/Irene/Desktop/AutomataAntelr/traducePyaJava/traducePyaJava.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,13,77,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,1,0,5,0,20,8,0,10,0,12,0,23,9,0,1,1,1,1,3,1,27,
        8,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,5,3,40,8,3,10,3,
        12,3,43,9,3,1,4,1,4,3,4,47,8,4,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,7,1,
        7,1,7,1,7,1,7,1,8,1,8,1,8,3,8,64,8,8,1,8,1,8,1,8,1,8,1,8,1,8,5,8,
        72,8,8,10,8,12,8,75,9,8,1,8,0,1,16,9,0,2,4,6,8,10,12,14,16,0,0,74,
        0,21,1,0,0,0,2,26,1,0,0,0,4,28,1,0,0,0,6,36,1,0,0,0,8,46,1,0,0,0,
        10,48,1,0,0,0,12,52,1,0,0,0,14,55,1,0,0,0,16,63,1,0,0,0,18,20,3,
        2,1,0,19,18,1,0,0,0,20,23,1,0,0,0,21,19,1,0,0,0,21,22,1,0,0,0,22,
        1,1,0,0,0,23,21,1,0,0,0,24,27,3,4,2,0,25,27,3,14,7,0,26,24,1,0,0,
        0,26,25,1,0,0,0,27,3,1,0,0,0,28,29,5,2,0,0,29,30,5,5,0,0,30,31,5,
        9,0,0,31,32,3,6,3,0,32,33,5,10,0,0,33,34,5,12,0,0,34,35,3,8,4,0,
        35,5,1,0,0,0,36,41,5,5,0,0,37,38,5,11,0,0,38,40,5,5,0,0,39,37,1,
        0,0,0,40,43,1,0,0,0,41,39,1,0,0,0,41,42,1,0,0,0,42,7,1,0,0,0,43,
        41,1,0,0,0,44,47,3,10,5,0,45,47,3,12,6,0,46,44,1,0,0,0,46,45,1,0,
        0,0,47,9,1,0,0,0,48,49,5,5,0,0,49,50,5,1,0,0,50,51,3,16,8,0,51,11,
        1,0,0,0,52,53,5,3,0,0,53,54,3,16,8,0,54,13,1,0,0,0,55,56,5,4,0,0,
        56,57,5,9,0,0,57,58,3,16,8,0,58,59,5,10,0,0,59,15,1,0,0,0,60,61,
        6,8,-1,0,61,64,5,5,0,0,62,64,5,6,0,0,63,60,1,0,0,0,63,62,1,0,0,0,
        64,73,1,0,0,0,65,66,10,4,0,0,66,67,5,7,0,0,67,72,3,16,8,5,68,69,
        10,3,0,0,69,70,5,8,0,0,70,72,3,16,8,4,71,65,1,0,0,0,71,68,1,0,0,
        0,72,75,1,0,0,0,73,71,1,0,0,0,73,74,1,0,0,0,74,17,1,0,0,0,75,73,
        1,0,0,0,7,21,26,41,46,63,71,73
    ]

class traducePyaJavaParser ( Parser ):

    grammarFileName = "traducePyaJava.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'def'", "'return'", "'print'", 
                     "<INVALID>", "<INVALID>", "'*'", "'-'", "'('", "')'", 
                     "','", "':'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "DEF", "RETURN", "PRINT", 
                      "ID", "NUMBER", "MUL", "SUB", "LPAREN", "RPAREN", 
                      "COMMA", "COLON", "WS" ]

    RULE_prog = 0
    RULE_stmt = 1
    RULE_func_def = 2
    RULE_param_list = 3
    RULE_stmt_block = 4
    RULE_expr_stmt = 5
    RULE_return_stmt = 6
    RULE_print_stmt = 7
    RULE_expr = 8

    ruleNames =  [ "prog", "stmt", "func_def", "param_list", "stmt_block", 
                   "expr_stmt", "return_stmt", "print_stmt", "expr" ]

    EOF = Token.EOF
    T__0=1
    DEF=2
    RETURN=3
    PRINT=4
    ID=5
    NUMBER=6
    MUL=7
    SUB=8
    LPAREN=9
    RPAREN=10
    COMMA=11
    COLON=12
    WS=13

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(traducePyaJavaParser.StmtContext)
            else:
                return self.getTypedRuleContext(traducePyaJavaParser.StmtContext,i)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)




    def prog(self):

        localctx = traducePyaJavaParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==2 or _la==4:
                self.state = 18
                self.stmt()
                self.state = 23
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def func_def(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Func_defContext,0)


        def print_stmt(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Print_stmtContext,0)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)




    def stmt(self):

        localctx = traducePyaJavaParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stmt)
        try:
            self.state = 26
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 24
                self.func_def()
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 25
                self.print_stmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Func_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEF(self):
            return self.getToken(traducePyaJavaParser.DEF, 0)

        def ID(self):
            return self.getToken(traducePyaJavaParser.ID, 0)

        def LPAREN(self):
            return self.getToken(traducePyaJavaParser.LPAREN, 0)

        def param_list(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Param_listContext,0)


        def RPAREN(self):
            return self.getToken(traducePyaJavaParser.RPAREN, 0)

        def COLON(self):
            return self.getToken(traducePyaJavaParser.COLON, 0)

        def stmt_block(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Stmt_blockContext,0)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_func_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunc_def" ):
                listener.enterFunc_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunc_def" ):
                listener.exitFunc_def(self)




    def func_def(self):

        localctx = traducePyaJavaParser.Func_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_func_def)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.match(traducePyaJavaParser.DEF)
            self.state = 29
            self.match(traducePyaJavaParser.ID)
            self.state = 30
            self.match(traducePyaJavaParser.LPAREN)
            self.state = 31
            self.param_list()
            self.state = 32
            self.match(traducePyaJavaParser.RPAREN)
            self.state = 33
            self.match(traducePyaJavaParser.COLON)
            self.state = 34
            self.stmt_block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Param_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(traducePyaJavaParser.ID)
            else:
                return self.getToken(traducePyaJavaParser.ID, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(traducePyaJavaParser.COMMA)
            else:
                return self.getToken(traducePyaJavaParser.COMMA, i)

        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_param_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam_list" ):
                listener.enterParam_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam_list" ):
                listener.exitParam_list(self)




    def param_list(self):

        localctx = traducePyaJavaParser.Param_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_param_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 36
            self.match(traducePyaJavaParser.ID)
            self.state = 41
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11:
                self.state = 37
                self.match(traducePyaJavaParser.COMMA)
                self.state = 38
                self.match(traducePyaJavaParser.ID)
                self.state = 43
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Stmt_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr_stmt(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Expr_stmtContext,0)


        def return_stmt(self):
            return self.getTypedRuleContext(traducePyaJavaParser.Return_stmtContext,0)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_stmt_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt_block" ):
                listener.enterStmt_block(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt_block" ):
                listener.exitStmt_block(self)




    def stmt_block(self):

        localctx = traducePyaJavaParser.Stmt_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_stmt_block)
        try:
            self.state = 46
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5]:
                self.enterOuterAlt(localctx, 1)
                self.state = 44
                self.expr_stmt()
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 2)
                self.state = 45
                self.return_stmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Expr_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(traducePyaJavaParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(traducePyaJavaParser.ExprContext,0)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_expr_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_stmt" ):
                listener.enterExpr_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_stmt" ):
                listener.exitExpr_stmt(self)




    def expr_stmt(self):

        localctx = traducePyaJavaParser.Expr_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_expr_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48
            self.match(traducePyaJavaParser.ID)
            self.state = 49
            self.match(traducePyaJavaParser.T__0)
            self.state = 50
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Return_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(traducePyaJavaParser.RETURN, 0)

        def expr(self):
            return self.getTypedRuleContext(traducePyaJavaParser.ExprContext,0)


        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_return_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturn_stmt" ):
                listener.enterReturn_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturn_stmt" ):
                listener.exitReturn_stmt(self)




    def return_stmt(self):

        localctx = traducePyaJavaParser.Return_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_return_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self.match(traducePyaJavaParser.RETURN)
            self.state = 53
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Print_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRINT(self):
            return self.getToken(traducePyaJavaParser.PRINT, 0)

        def LPAREN(self):
            return self.getToken(traducePyaJavaParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(traducePyaJavaParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(traducePyaJavaParser.RPAREN, 0)

        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_print_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrint_stmt" ):
                listener.enterPrint_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrint_stmt" ):
                listener.exitPrint_stmt(self)




    def print_stmt(self):

        localctx = traducePyaJavaParser.Print_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_print_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 55
            self.match(traducePyaJavaParser.PRINT)
            self.state = 56
            self.match(traducePyaJavaParser.LPAREN)
            self.state = 57
            self.expr(0)
            self.state = 58
            self.match(traducePyaJavaParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(traducePyaJavaParser.ID, 0)

        def NUMBER(self):
            return self.getToken(traducePyaJavaParser.NUMBER, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(traducePyaJavaParser.ExprContext)
            else:
                return self.getTypedRuleContext(traducePyaJavaParser.ExprContext,i)


        def MUL(self):
            return self.getToken(traducePyaJavaParser.MUL, 0)

        def SUB(self):
            return self.getToken(traducePyaJavaParser.SUB, 0)

        def getRuleIndex(self):
            return traducePyaJavaParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = traducePyaJavaParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 63
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5]:
                self.state = 61
                self.match(traducePyaJavaParser.ID)
                pass
            elif token in [6]:
                self.state = 62
                self.match(traducePyaJavaParser.NUMBER)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 73
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,6,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 71
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
                    if la_ == 1:
                        localctx = traducePyaJavaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 65
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 66
                        self.match(traducePyaJavaParser.MUL)
                        self.state = 67
                        self.expr(5)
                        pass

                    elif la_ == 2:
                        localctx = traducePyaJavaParser.ExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 68
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 69
                        self.match(traducePyaJavaParser.SUB)
                        self.state = 70
                        self.expr(4)
                        pass

             
                self.state = 75
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[8] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         




