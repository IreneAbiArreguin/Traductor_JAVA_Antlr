from traducePyaJavaListener import *
from traducePyaJavaParser import *

class traductor(ParseTreeListener):
    def __init__(self):
        self.codigo_java = []  

    def agregar_linea(self, linea):
        """Se añaden las lineas de codigo"""
        self.codigo_java.append(linea)

    def enterProg(self, ctx: traducePyaJavaParser.ProgContext):
        self.agregar_linea("public class python {")

    def exitProg(self, ctx: traducePyaJavaParser.ProgContext):
        self.agregar_linea("""  
     public static void main(String[] args) {
        System.out.println(multiplica(5, 6));
    }
}
""")

    def enterFunc_def(self, ctx: traducePyaJavaParser.Func_defContext):
        func_name = ctx.ID().getText()
        params = [param.getText() for param in ctx.param_list().ID()]
        param_str = ", ".join(f"int {p}" for p in params)
        self.agregar_linea(f"    public static int {func_name}({param_str}) {{")

    def exitFunc_def(self, ctx: traducePyaJavaParser.Func_defContext):
        self.agregar_linea("        return result;")  # Agregar el return de la función
        self.agregar_linea("    }")

    def enterExpr_stmt(self, ctx: traducePyaJavaParser.Expr_stmtContext):
        var_name = ctx.ID().getText()
        expr = self.obtener_expr(ctx.expr())
        self.agregar_linea(f"        int {var_name} = {expr};")  # Asignación de variable

    def enterReturn_stmt(self, ctx: traducePyaJavaParser.Return_stmtContext):
        expr = self.obtener_expr(ctx.expr())
        self.agregar_linea(f"        return {expr};")

    def enterPrint_stmt(self, ctx: traducePyaJavaParser.Print_stmtContext):
        expr = self.obtener_expr(ctx.expr())
        self.agregar_linea(f"        System.out.println({expr});")

    def obtener_expr(self, ctx):
        if ctx.MUL():
            left = self.obtener_expr(ctx.expr(0))
            right = self.obtener_expr(ctx.expr(1))
            return f"{left} * {right}"
        elif ctx.SUB():
            left = self.obtener_expr(ctx.expr(0))
            right = self.obtener_expr(ctx.expr(1))
            return f"{left} - {right}"
        elif ctx.ID():
            return ctx.ID().getText()
        elif ctx.NUMBER():
            return ctx.NUMBER().getText()

    def get_codigo_java(self):
        return '\n'.join(self.codigo_java)

    # Cambiado para que agregue 'int' explícitamente en la declaración
    def enterAssign_stmt(self, ctx: traducePyaJavaParser.Expr_stmtContext):
        var_name = ctx.ID().getText()
        expr = self.obtener_expr(ctx.expr())
        self.agregar_linea(f"        int {var_name} = {expr};")  # Declaración y asignación en una línea

